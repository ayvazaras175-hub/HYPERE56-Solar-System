HYPERE56 - Procedural Texture Pack
=================================
Contains original procedural equirectangular PNG surface maps:
- 12 main planet textures
- 1 HYPERE56 star texture

Resolution: 1024 x 512 pixels
Format: PNG, RGB

These are newly generated fictional textures, not official SFS assets.
They are visual texture assets only. The planet TXT files have NOT been
modified or uploaded to GitHub, because the exact custom-texture import
mapping still needs to be verified against the installed SFS modding toolkit.
